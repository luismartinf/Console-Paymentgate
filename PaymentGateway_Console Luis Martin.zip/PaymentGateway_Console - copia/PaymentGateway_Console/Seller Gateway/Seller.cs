﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGateway_Console
{
    //Field and Properties for the Sellers inheritace from the class Client
    class seller : Client
    {
        //Override method to retrieve the shhiping information of the Seller
        public override Tuple<int, int, double> Item_num(int Order_number = 0, int Shipping_item = 000000, double Shipping_cost = 0.00)
        {
            Tuple<int, int, double> item_creation = Tuple.Create(Order_number, Shipping_item, Shipping_cost);
            return item_creation;
        }
    }
}
