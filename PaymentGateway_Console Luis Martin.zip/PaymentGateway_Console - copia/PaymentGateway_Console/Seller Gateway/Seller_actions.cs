﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGateway_Console
{
    // class with the actions of a seller: Add/ Delete/ View and Make a new transaction(shipping)
    class Sellor_actions: IActions_info
    {

        //Method to add a seller
        public object Add_info()
        {
            // Retrieve information from the Sellers saved in the seller txt file
            seller seller = new seller();
            Console.WriteLine("Country");
            seller.Country1 = Console.ReadLine();
            Console.WriteLine("Type Card");
            seller.Type_Card1 = Console.ReadLine();
            Console.WriteLine("16 digits of Card Number");
            seller.Card_N1 = Convert.ToInt64(Console.ReadLine());
            int L_Card = Convert.ToString(seller.Card_N1).Length;
            //validate the card contains 16 digits exactly to deposit the money of the transaction
            bool Validcard = L_Card == 16;
            while (!Validcard)
            {
                Console.WriteLine("Card Number is Wrong, reenter the value");
                seller.Card_N1 = Convert.ToInt64(Console.ReadLine());
                L_Card = Convert.ToString(seller.Card_N1).Length;
                Validcard = L_Card == 16;
            }

            //Information for the shop adress
            Console.WriteLine("First Name");
            seller.First_N1 = Console.ReadLine();
            Console.WriteLine("Last Name");
            seller.Last_N1 = Console.ReadLine();
            Console.WriteLine("Address Line 1");
            seller.Add_11 = Console.ReadLine();
            Console.WriteLine("Address Line 2");
            seller.Add_21 = Console.ReadLine();
            Console.WriteLine("City if that is the case");
            seller.City1 = Console.ReadLine();
            Console.WriteLine("State");
            seller.State1 = Console.ReadLine();
            Console.WriteLine("Postal Code");
            seller.CP1 = Console.ReadLine();
            Console.WriteLine("Password");

            //password for the app, the user is the name.
            seller.Password1 = Console.ReadLine();

            // Asking if want to ship something, and collect he data for the shipping
            //Note: The data of the shipping is retrived from the seller 
            // and the data is saved in the purchase txt file.
            Console.WriteLine("Do you want to shiiping something Yes/NO");
            string validpurchase = Console.ReadLine();
            if (validpurchase == "Yes")
            {
                Console.WriteLine("Order Number");
                int Order_number = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Shipping Item");
                int Shipping_item = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Shipping Cost");
                double Shipping_cost = Convert.ToDouble(Console.ReadLine());
                seller.Item1 = seller.Item_num(Order_number, Shipping_item, Shipping_cost);
            }
            else
            { seller.Item1 = seller.Item_num(); }
            return seller;
        }
        seller[] Sellers = Menu.Sellers_list;
        //Method to delete the information saved in the client list from a client
        public void Delete_info(object card_seller)
        {
            long card_delete = Convert.ToInt64(card_seller);
            Sellers = Sellers.Where(Sellers => Sellers.Card_N1 != card_delete).ToArray();
            Menu.Sellers_list = Sellers;
        }
        //Method to show the information saved from the client

        public void Show_info(object seller_data)
        {

            seller Sellers = (seller) seller_data;
            Console.WriteLine(Sellers.ToString());
        }


    }
}
