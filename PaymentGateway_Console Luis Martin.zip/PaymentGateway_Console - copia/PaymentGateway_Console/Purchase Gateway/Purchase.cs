﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGateway_Console
{
    //Class to saved the transactions of all the clients and Sellers  
    class Purchase
    {
        //Fields of each purchase
        int Order_number;
        int Purchase_item;
        double Purchase_amount;
        int Shipping_item;
        double Shipping_cost;

        //properties of the purchases
        public int Order_number1 { get => Order_number; set => Order_number = value; }
        public int Purchase_item1 { get => Purchase_item; set => Purchase_item = value; }
        public double Purchase_amount1 { get => Purchase_amount; set => Purchase_amount = value; }
        public int Shipping_item1 { get => Shipping_item; set => Shipping_item = value; }
        public double Shipping_cost1 { get => Shipping_cost; set => Shipping_cost = value; }
    }
}
