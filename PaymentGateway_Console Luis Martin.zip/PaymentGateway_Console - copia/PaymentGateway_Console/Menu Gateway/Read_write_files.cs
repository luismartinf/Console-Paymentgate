﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGateway_Console
{
    //Class to read and write the Client/ seller and Puchase tct files from the arrays
    class Read_write_files
    {
        public object[] Read_list(string text_file, string filepath, string data_list)
        {
            // path to store the file
            string path = filepath + text_file;
            string[] Clients_file;
            // Validate if exist each file acording to the data provide in the string (Clients/ Sellers/ Purchase)
            // If the file exist read the data in the file and return an array with the corresponding objects
            // else create a new array with the corresponding class
            if (File.Exists(path))
            {
                // array of strings with all the clients Sellers or purchases saved each one in one line
                Clients_file = File.ReadAllLines(path);
                int Len_clients = Clients_file.Length;
                if (text_file == "Clients Gateway")
                {

                    Client[] List_added = new Client[Len_clients];
                    for (int n_clients = 0; n_clients < Len_clients; n_clients++)
                    {
                        //string array with each value for all the fields of a client
                        string[] client_added = new string[14];
                        string str_field = "";
                        int num_field = 0;
                        foreach (char chart_c in Clients_file[n_clients])
                        {
                            if (chart_c == ',')
                            {
                                client_added[num_field] = str_field;
                                str_field = "";
                                num_field++;
                            }
                            else
                            { str_field = str_field + chart_c; }

                        }
                        //Reading and creating the array for all the clients
                        Client client_s = new Client
                        {
                            Country1 = client_added[0],
                            Type_Card1 = client_added[1],
                            Card_N1 = Convert.ToInt64(client_added[2]),
                            Exp_date1 = DateTime.Parse(client_added[3]),
                            CVV1 = Convert.ToInt16(client_added[4]),
                            First_N1 = client_added[5],
                            Last_N1 = client_added[6],
                            Add_11 = client_added[7],
                            Add_21 = client_added[8],
                            City1 = client_added[9],
                            State1 = client_added[10],
                            CP1 = client_added[11],
                            Add_date1 = DateTime.Parse(client_added[12]),
                            Password1 = client_added[13]
                        };
                        client_s.Item1 = client_s.Item_num();
                        List_added[n_clients] = client_s;
                    }
                    Menu.Clients_list = List_added;
                    return List_added;
                }
                else if (text_file == "Sellers Gateway")
                {
                    // string array with each value for all the fields of a client
                    seller[] List_added = new seller[Len_clients];
                    for (int n_clients = 0; n_clients < Len_clients; n_clients++)
                    {
                        string[] client_added = new string[12];
                        string str_field = "";
                        int num_field = 0;
                        foreach (char chart_c in Clients_file[n_clients])
                        {
                            if (chart_c == ',')
                            {
                                client_added[num_field] = str_field;
                                str_field = "";
                                num_field++;
                            }
                            else
                            { str_field = str_field + chart_c; }

                        }
                        //Reading and creating the array for all the Sellers
                        seller sellor_s = new seller
                        {
                            Country1 = client_added[0],
                            Type_Card1 = client_added[1],
                            Card_N1 = Convert.ToInt64(client_added[2]),
                            First_N1 = client_added[3],
                            Last_N1 = client_added[4],
                            Add_11 = client_added[5],
                            Add_21 = client_added[6],
                            City1 = client_added[7],
                            State1 = client_added[8],
                            CP1 = client_added[9],
                            Add_date1 = DateTime.Parse(client_added[10]),
                            Password1 = client_added[11]
                        };
                        sellor_s.Item1 = sellor_s.Item_num();
                        List_added[n_clients] = sellor_s;
                    }
                    Menu.Sellers_list = List_added;
                    return List_added;
                }
                else
                {
                    Purchase[] List_added = new Purchase[Len_clients];
                    for (int n_clients = 0; n_clients < Len_clients; n_clients++)
                    {
                        string[] client_added = new string[5];
                        string str_field = "";
                        int num_field = 0;
                        foreach (char chart_c in Clients_file[n_clients])
                        {
                            if (chart_c == ',')
                            {
                                client_added[num_field] = str_field;
                                str_field = "";
                                num_field++;
                            }
                            else
                            { str_field = str_field + chart_c; }

                        }
                        //Reading and creating the array for all the clients
                        Purchase purchase_s = new Purchase
                        {
                            Order_number1 = Convert.ToInt32(client_added[0]),
                            Purchase_item1 = Convert.ToInt32(client_added[1]),
                            Purchase_amount1 = Convert.ToDouble(client_added[2]),
                            Shipping_item1 = Convert.ToInt32(client_added[3]),
                            Shipping_cost1 = Convert.ToDouble(client_added[4])
                        };
                        List_added[n_clients] = purchase_s;
                    }
                    Menu.Purchase_list = List_added;
                    return List_added;
                }
            }
            //create a ne client, seller or purchase array
            else
            {
                if (data_list == "Clients")
                {
                    Client[] List_added = new Client[0];
                    return List_added;
                }
                else if (data_list == "Sellers")
                {
                    seller[] List_added = new seller[0];
                    return List_added;
                }
                else
                {
                    Purchase[] List_added = new Purchase[0];
                    return List_added;
                }
            }


        }
        //Method to write a Client txt file
        public void Write_file(string text_file, Client[] Clients_added, string filepath)
        {
            string[] clients_saved = new string[Clients_added.Length];
            for (int client_num = 0; client_num < clients_saved.Length; client_num++)
            {
                Client client_string = Clients_added[client_num];
                clients_saved[client_num] = $"{client_string.Country1},{client_string.Type_Card1},{client_string.Card_N1},{client_string.Exp_date1},{client_string.CVV1},{client_string.First_N1},{client_string.Last_N1},{client_string.Add_11},{client_string.Add_21},{client_string.City1},{client_string.State1},{client_string.CP1},{client_string.Add_date1},{client_string.Password1},";
            }
            string path = filepath + text_file;
            File.WriteAllLines(path, clients_saved, Encoding.UTF8);

        }
        //Method to write a seller txt file
        public void Write_file(string text_file, seller[] Sellor_added, string filepath)
        {
            string[] sellor_saved = new string[Sellor_added.Length];
            for (int sellor_num = 0; sellor_num < sellor_saved.Length; sellor_num++)
            {
                seller sellor_string = Sellor_added[sellor_num];
                sellor_saved[sellor_num] = $"{sellor_string.Country1},{sellor_string.Type_Card1},{sellor_string.Card_N1},{sellor_string.First_N1},{sellor_string.Last_N1},{sellor_string.Add_11},{sellor_string.Add_21},{sellor_string.City1},{sellor_string.State1},{sellor_string.CP1},{sellor_string.Add_date1},{sellor_string.Password1},";
            }
            string path = filepath + text_file;
            File.WriteAllLines(path, sellor_saved, Encoding.UTF8);

        }
        //Method to write a Purchase txt file
        public void Write_file(string text_file, Purchase[] Purchase_added, string filepath)
        {
            string[] purchase_saved = new string[Purchase_added.Length];
            for (int purchase_num = 0; purchase_num < purchase_saved.Length; purchase_num++)
            {
                Purchase purchase_string = Purchase_added[purchase_num];
                purchase_saved[purchase_num] = $"{purchase_string.Order_number1},{purchase_string.Purchase_item1},{purchase_string.Purchase_amount1},{purchase_string.Shipping_item1},{purchase_string.Shipping_cost1},";
            }
            string path = filepath + text_file;
            File.WriteAllLines(path, purchase_saved, Encoding.UTF8);

        }



    }
}
