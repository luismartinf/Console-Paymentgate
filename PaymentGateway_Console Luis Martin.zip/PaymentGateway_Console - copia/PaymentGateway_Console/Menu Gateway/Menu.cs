﻿using System;
using System.IO;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGateway_Console

{   //Menu to display the options of the clients
    class Menu
    {
        //Arrays to saved the information of clients, Sellers and purchases in txt iles
        public static object[][] Gateway;
        public static seller[] Sellers_list;
        public static Client[] Clients_list;
        public static Purchase[] Purchase_list;

        //menu of the client
        public static void Menu_clients()
        //read the database of clients
        {
            Read_write_files files_rw = new Read_write_files();
            Client_actions client_actions = new Client_actions();
            //path where is saved the file  (@"C:\Users\luis.martin\Downloads)
            Client[] Clients = (Client[])files_rw.Read_list("Clients Gateway", @"C:\Users\luis.martin\Downloads\", "Clients");
            Console.WriteLine($"If you are new client, you need to add your information type A");
            Console.WriteLine($"If you saved your information and want delete it type D");
            Console.WriteLine($"If you saved your information and want new purchase type P");
            Console.WriteLine($"If you saved your information and want to view type V");
            char options = Convert.ToChar(Console.ReadLine());
            bool validoption = false;
            //    Validate one of the four possible actions Add/ Delete/ Purchase/ View       
            while (!validoption)
            {
                switch (options)
                {
                    case 'A':
                        //Create an array for store the values of the new client resizing the previous one
                        int c_used = Clients.Length;
                        Array.Resize(ref Clients, c_used + 1);
                        bool correct_data = false;
                        //Check if the information is correct otherwise reenter the information
                        while (!correct_data)
                        {
                            Clients[c_used] =(Client) client_actions.Add_info();
                            Console.WriteLine("This is your information");
                            client_actions.Show_info(Clients[c_used]);
                            Console.WriteLine($"Your data saved {Clients[c_used].Add_date1} is correct Yes/No?");
                            string validinformation = Console.ReadLine();
                            if (validinformation == "Yes")
                            { correct_data = true; }
                            else
                            {
                                Clients[c_used] = (Client)client_actions.Add_info();
                                Console.WriteLine("This is your information");
                                client_actions.Show_info(Clients[c_used]);
                                Console.WriteLine($"Your data to save {Clients[c_used].Add_date1} is correct Yes/No?");
                                validinformation = Console.ReadLine();
                                correct_data = false;
                            }
                        }
                        //Update the clients array
                        Clients_list = Clients;
                        //Update the client list that is a txt file saved from the array
                        files_rw.Write_file("Clients Gateway", Clients_list, @"C:\Users\luis.martin\Downloads\");
                        validoption = true;
                        break;

                    case 'D':
                        // Search the client information
                        Console.WriteLine("Enter your card number");
                        long card_delete = Convert.ToInt64(Console.ReadLine());
                        foreach (var item_C in Clients)
                        {
                            if (item_C.Card_N1 == card_delete)
                            {
                                //Confirm to erase the information to add new one with the password with 3 attempts 
                                Console.WriteLine("If you want to erase your information enter your password");
                                string key_client = Console.ReadLine();
                                int attempts = 0;
                                bool correct_pas = false;
                                while (!correct_pas | attempts < 3)
                                {
                                    if (item_C.Password1 == key_client)
                                    {
                                        //Delete client information
                                        client_actions.Delete_info(item_C.Card_N1);
                                        Console.WriteLine("Personal Information Deleted");
                                        files_rw.Write_file("Clients Gateway", Clients_list, @"C:\Users\luis.martin\Downloads\");
                                        correct_pas = true;
                                    }
                                    else
                                    {
                                        attempts++;
                                        Console.WriteLine($"Incorrect pasword, try again remain attempst {3 - attempts}");
                                        key_client = Console.ReadLine();
                                        correct_pas = false;
                                    }
                                }
                            }
                        }
                        validoption = true;
                        break;

                    case 'P':
                        Console.WriteLine("Enter your card number");
                        //find the client information to do a new purchase
                        long card_num = Convert.ToInt64(Console.ReadLine());
                        foreach (var item_C in Clients)
                        {
                            if (item_C.Card_N1 == card_num)
                            {

                                Console.WriteLine("If you want to purchase enter your password");
                                string key_client = Console.ReadLine();
                                int attempts = 0;
                                bool correct_pas = false;
                                while (!correct_pas | attempts < 3)
                                {
                                    if (item_C.Password1 == key_client)
                                    {
                                        // Confirm the trasaction and client information with password 3 attempts
                                        Console.WriteLine("This is your information");
                                        client_actions.Show_info(item_C);
                                        // Do the new transaction
                                        //client_actions.Purchase_client(item_C.Card_N);
                                        Console.WriteLine("Succesful Purchase the Order Number and Shipped Order are");
                                        // Return the information of the transaction
                                        //Console.WriteLine($"Shipped Order: { } ");
                                        correct_pas = true;
                                    }
                                    else
                                    {
                                        attempts++;
                                        Console.WriteLine($"Incorrect pasword, try again remain attempst {3 - attempts}");
                                        key_client = Console.ReadLine();
                                        correct_pas = false;
                                    }
                                }
                            }
                        }
                        validoption = true;
                        break;

                    case 'V':
                        Console.WriteLine("Enter your card number");
                        card_num = Convert.ToInt64(Console.ReadLine());
                        // Find client information to display
                        foreach (var item_C in Clients)
                        {
                            if (item_C.Card_N1 == card_num)
                            {
                                Console.WriteLine("If you want to view your information enter your password");
                                string key_client = Console.ReadLine();
                                int attempts = 0;
                                bool correct_pas = false;
                                while (!correct_pas | attempts < 3)
                                {
                                    if (item_C.Password1 == key_client)
                                    {
                                        Console.WriteLine($"This is your information saved {item_C.Add_date1}");
                                        client_actions.Show_info(item_C);
                                        Console.WriteLine("If is not correct deleted your data and add the new one");
                                        correct_pas = true;
                                    }
                                    else
                                    {
                                        attempts++;
                                        Console.WriteLine($"Incorrect pasword, try again remain attempst {3 - attempts}");
                                        key_client = Console.ReadLine();
                                        correct_pas = false;
                                    }
                                }
                            }
                        }
                        validoption = true;
                        break;
                    default:
                        Console.WriteLine("Option not exist, reenter the value");
                        Console.WriteLine($"If you are new client, you need to add your information type A");
                        Console.WriteLine($"If you saved your information and want delete it type D");
                        Console.WriteLine($"If you saved your information and want new purchase type P");
                        Console.WriteLine($"If you saved your information and want to view type V");
                        options = Convert.ToChar(Console.ReadLine());
                        validoption = false;
                        break;
                }
            }
        }

        //Menu for the seller 
        public static void Menu_sellors()
        {
            //Read the file with the Sellers information
            Read_write_files files_rw = new Read_write_files();
            Sellor_actions sellor_actions = new Sellor_actions();
            //path where is saved the file  (@"C:\Users\luis.martin\Downloads)
            seller[] Sellers = (seller[])files_rw.Read_list("Sellers Gateway", @"C: \Users\luis.martin\Downloads\", "Sellers");
            // Sellect one of the four possible actions Add/ Delete/ Shipping/ View for a seller and validate 
            Console.WriteLine($"If you are new seller, you need to add your information type A");
            Console.WriteLine($"If you saved your information and want delete it type D");
            Console.WriteLine($"If you saved your information and want new shipping type S");
            Console.WriteLine($"If you saved your information and want to view type V");
            char options = Convert.ToChar(Console.ReadLine());
            bool validoption = false;
            while (!validoption)
            {
                switch (options)
                {
                    case 'A':
                        //Modifing the size of the seller array to create a new seller
                        int c_used = Sellers.Length;
                        Array.Resize(ref Sellers, c_used + 1);
                        bool correct_data = false;
                        //Check the correct information to be saved fron the Sellers
                        while (!correct_data)
                        {
                            Sellers[c_used] = (seller)sellor_actions.Add_info();
                            Console.WriteLine("This is your information");
                            sellor_actions.Show_info(Sellers[c_used]);
                            Console.WriteLine($"Your data saved {Sellers[c_used].Add_date1} is correct Yes/No?");
                            string validinformation = Console.ReadLine();
                            if (validinformation == "Yes")
                            { correct_data = true; }
                            else
                            {
                                Sellers[c_used] =(seller) sellor_actions.Add_info();
                                Console.WriteLine("This is your information");
                                sellor_actions.Show_info(Sellers[c_used]);
                                Console.WriteLine($"Your data to save {Sellers[c_used].Add_date1} is correct Yes/No?");
                                validinformation = Console.ReadLine();
                                correct_data = false;
                            }
                        }
                        //Update array of Sellers
                        Sellers_list = Sellers;
                        //Update txt file for Sellers
                        files_rw.Write_file("Sellers Gateway", Sellers_list, @"C:\Users\luis.martin\Downloads\");
                        validoption = true;
                        break;

                    case 'D':
                        Console.WriteLine("Enter your card number");
                        //Finf the information of the seller
                        long card_delete = Convert.ToInt64(Console.ReadLine());
                        foreach (var item_C in Sellers)
                        {
                            if (item_C.Card_N1 == card_delete)
                            {
                                // Validate with the password maximun in three attempts to erase the data
                                Console.WriteLine("If you want to erase your information enter your password");
                                string key_client = Console.ReadLine();
                                int attempts = 0;
                                bool correct_pas = false;
                                while (!correct_pas | attempts < 3)
                                {
                                    if (item_C.Password1 == key_client)
                                    {
                                        //errase the data
                                        sellor_actions.Delete_info(item_C.Card_N1);
                                        Console.WriteLine("Personal Information Deleted");
                                        files_rw.Write_file("Sellers Gateway", Sellers_list, @"C:\Users\luis.martin\Downloads\");
                                        correct_pas = true;
                                    }
                                    else
                                    {
                                        attempts++;
                                        Console.WriteLine($"Incorrect pasword, try again remain attempst {3 - attempts}");
                                        key_client = Console.ReadLine();
                                        correct_pas = false;
                                    }
                                }
                            }
                        }
                        validoption = true;
                        break;

                    case 'S':
                        Console.WriteLine("Enter your card number");
                        //find the seelor´s data to a new shhiping
                        long card_num = Convert.ToInt64(Console.ReadLine());
                        foreach (var item_C in Sellers)
                        {
                            if (item_C.Card_N1 == card_num)
                            {

                                Console.WriteLine("If you want to shhiping enter your password");
                                string key_client = Console.ReadLine();
                                int attempts = 0;
                                bool correct_pas = false;
                                while (!correct_pas | attempts < 3)
                                {
                                    if (item_C.Password1 == key_client)
                                    {
                                        Console.WriteLine("This is your information");
                                        sellor_actions.Show_info(item_C);
                                        // Creating a new shipping from a seller
                                        //sellor_actions.Purchase_client(item_C.Card_N);
                                        Console.WriteLine("Succesful Shipping the Order Number and Purchase Item are");
                                        // Displaying the Items Purchase by the client
                                        //Console.WriteLine($"Shipped Order: { } ");
                                        correct_pas = true;
                                    }
                                    else
                                    {
                                        attempts++;
                                        Console.WriteLine($"Incorrect pasword, try again remain attempst {3 - attempts}");
                                        key_client = Console.ReadLine();
                                        correct_pas = false;
                                    }
                                }
                            }
                        }
                        validoption = true;
                        break;

                    case 'V':
                        Console.WriteLine("Enter your card number");
                        //Finding the information of a seller for display it
                        card_num = Convert.ToInt64(Console.ReadLine());
                        foreach (var item_C in Sellers)
                        {
                            if (item_C.Card_N1 == card_num)
                            {
                                //VAlidating the display of the data with the password with maximun 3 attempts
                                Console.WriteLine("If you want to view your information enter your password");
                                string key_client = Console.ReadLine();
                                int attempts = 0;
                                bool correct_pas = false;
                                while (!correct_pas | attempts < 3)
                                {
                                    if (item_C.Password1 == key_client)
                                    {
                                        Console.WriteLine($"This is your information saved {item_C.Add_date1}");
                                        sellor_actions.Show_info(item_C);
                                        Console.WriteLine("If is not correct deleted your data and add the new one");
                                        correct_pas = true;
                                    }
                                    else
                                    {
                                        attempts++;
                                        Console.WriteLine($"Incorrect pasword, try again remain attempst {3 - attempts}");
                                        key_client = Console.ReadLine();
                                        correct_pas = false;
                                    }
                                }
                            }
                        }
                        validoption = true;
                        break;
                    default:
                        Console.WriteLine("Option not exist, reenter the value");
                        Console.WriteLine($"If you are new client, you need to add your information type A");
                        Console.WriteLine($"If you saved your information and want delete it type D");
                        Console.WriteLine($"If you saved your information and want new purchase type P");
                        Console.WriteLine($"If you saved your information and want to view type V");
                        options = Convert.ToChar(Console.ReadLine());
                        validoption = false;
                        break;
                }
            }
        }
        public static void Menu_managers()
        {
            //   Menu for the managers
            //   Read and Display all the information of the three databases CLient, Sellers and Transactions in a object jared array
            Read_write_files files_rw = new Read_write_files();
            Gateway = new object[3][];
            Client[] Clients = (Client[])files_rw.Read_list("Clients Gateway", @"C: \Users\luis.martin\Downloads\", "Clients");
            Gateway[0] = Clients;
            seller[] Sellers = (seller[])files_rw.Read_list("Sellers Gateway", @"C: \Users\luis.martin\Downloads\", "Sellers");
            Gateway[1] = Sellers;
            Purchase[] Purchases = (Purchase[])files_rw.Read_list("Purchases Gateway", @"C: \Users\luis.martin\Downloads\", "Purchases");
            Gateway[2] = Purchases;
        }



    }
}