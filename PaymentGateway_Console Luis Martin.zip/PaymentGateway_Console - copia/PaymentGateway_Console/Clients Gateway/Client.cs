﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGateway_Console
{
    //Class to save the personal information of the Clients or Sellers
    class Client

    {   //Fields with the data of the Client/seller
        string Country;
        string Type_Card;
        long Card_N;
        DateTime Exp_date;
        short CVV;
        string First_N;
        string Last_N;
        string Add_1;
        string Add_2;
        string City;
        string State;
        string CP;
        DateTime Add_date;
        string Password;

        // Tuple saved in the Purchase file
        Tuple<int, int, double> Item;

        //Initial data for values that are not allways retrived in the case of city in some cases doesn´t exist,
        //Add date is assigned automatically and their property is for read from the txt file
        //Exp_date and CVV aren´t relevant for the seller to use the inheritance of the class they have dummy values
        public Client()
        {
            Add_date1 = DateTime.Now;
            City1 = "";
            Exp_date = DateTime.Now;
            CVV = 000;
        }

        //Constructor for retieved the data for each purchase
        public virtual Tuple<int, int, double> Item_num(int Order_number = 0, int Purchase_item = 000000, double Purchase_amount = 0.00)
        {
            Tuple<int, int, double> item_creation = Tuple.Create(Order_number, Purchase_item, Purchase_amount);
            return item_creation;
        }

        //Properties for the fields
        public string Country1 { get => Country; set => Country = value; }
        public string Type_Card1 { get => Type_Card; set => Type_Card = value; }
        public long Card_N1 { get => Card_N; set => Card_N = value; }
        public DateTime Exp_date1 { get => Exp_date; set => Exp_date = value; }
        public short CVV1 { get => CVV; set => CVV = value; }
        public string First_N1 { get => First_N; set => First_N = value; }
        public string Last_N1 { get => Last_N; set => Last_N = value; }
        public string Add_11 { get => Add_1; set => Add_1 = value; }
        public string Add_21 { get => Add_2; set => Add_2 = value; }
        public string City1 { get => City; set => City = value; }
        public string State1 { get => State; set => State = value; }
        public string CP1 { get => CP; set => CP = value; }
        public DateTime Add_date1 { get => Add_date; set => Add_date = value; }
        public string Password1 { get => Password; set => Password = value; }
        public Tuple<int, int, double> Item1 { get => Item; set => Item = value; }

        //Override method to display the data of the Client/seller
        public override string ToString()
        {
            long L4_digit = Card_N1 % 10000;
            string Display = "";
            if (City1 == "")
            { Display = $"Name: {First_N1} {Last_N1} \n Card Number **** **** **** **** {L4_digit} \n Billing Adress: {Add_11}, {Add_21}, {CP1}, {State1}, {Country1}"; }
            else
            { Display = $"Name: {First_N1} {Last_N1} \n Card Number **** **** **** **** {L4_digit} \n Billing Adress: {Add_11}, {Add_21}, {CP1}, {City1}, {State1}, {Country1}"; }
            return Display;
        }
    }
}
