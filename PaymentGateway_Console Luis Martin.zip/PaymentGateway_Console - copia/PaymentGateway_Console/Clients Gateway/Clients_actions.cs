﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGateway_Console
{
    // class with the actions of a client: Add/ Delete/ View and Make a new transaction(purchase)
    class Client_actions:IActions_info
    {
        
        
        //Method to add a client
        public object Add_info()
        {
            // retrieve information from the client saved in the client txt file
            Client client = new Client();
            Console.WriteLine("Country");
            client.Country1 = Console.ReadLine();
            Console.WriteLine("Type Card");
            client.Type_Card1 = Console.ReadLine();
            Console.WriteLine("16 digits of Card Number");
            client.Card_N1 = Convert.ToInt64(Console.ReadLine());
            int L_Card = Convert.ToString(client.Card_N1).Length;

            //validate the card contains 16 digits exactly
            bool Validcard = L_Card == 16;
            while (!Validcard)
            {
                Console.WriteLine("Card Number is Wrong, reenter the value");
                client.Card_N1 = Convert.ToInt64(Console.ReadLine());
                L_Card = Convert.ToString(client.Card_N1).Length;
                Validcard = L_Card == 16;
            }

            //retrieve security data
            Console.WriteLine("Expired Date MM/YY");
            client.Exp_date1 = DateTime.ParseExact(Console.ReadLine(), "MM/yy", CultureInfo.InvariantCulture);
            Console.WriteLine("CVV");

            //Information for the billing adress
            client.CVV1 = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("First Name");
            client.First_N1 = Console.ReadLine();
            Console.WriteLine("Last Name");
            client.Last_N1 = Console.ReadLine();
            Console.WriteLine("Address Line 1");
            client.Add_11 = Console.ReadLine();
            Console.WriteLine("Address Line 2");
            client.Add_21 = Console.ReadLine();
            Console.WriteLine("City if that is the case");
            client.City1 = Console.ReadLine();
            Console.WriteLine("State");
            client.State1 = Console.ReadLine();
            Console.WriteLine("Postal Code");
            client.CP1 = Console.ReadLine();

            //password for the app, the user is the name.
            Console.WriteLine("Password");

            // Asking if want to purchase something, and collect he data for the purchase
            //Note: The data of the puchase is retrived from the client since doesn´t exist a online shopping 
            // and the data is saved in the purchase txt file.
            client.Password1 = Console.ReadLine();
            Console.WriteLine("Do you want to purchase something Yes/NO");
            string validpurchase = Console.ReadLine();
            if (validpurchase == "Yes")
            {
                Console.WriteLine("Order Number");
                int Order_number = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Purchase Item");
                int Purchase_item = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Purchase Amount");
                double Purchase_amount = Convert.ToDouble(Console.ReadLine());
                client.Item1 = client.Item_num(Order_number, Purchase_item, Purchase_amount);
            }
            else
            { client.Item1 = client.Item_num(); }
            return client;
        }
        Client[] clients = Menu.Clients_list;
        //Method to delete the information saved in the client list from a client
        public void Delete_info(object card_user)
        {
            long card_delete = Convert.ToInt64(card_user);
            clients = clients.Where(clients => clients.Card_N1 != card_delete).ToArray();
            Menu.Clients_list = clients;
        }
        //Method to show the information saved from the client
       
        public void Show_info(object client_data)
        {

            Client client = (Client)client_data;
            Console.WriteLine(client.ToString());
        }
    }
}

